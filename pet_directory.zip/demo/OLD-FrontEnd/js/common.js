	var site_path	= 'http://projects.selvitech.com/jyjoo/demo';

	

	function postComment()	{

		showOverlay();

		var	comment		= $('#comment');

		var token		= $('#token');

		var post_id		= $('#post_id');

		var reply_to	= $('#reply_to');

		var thread_id	= $('#thread_id');

		

		var errorbox	= $('#comment_error');

		var successbox	= $('#comment_success');

				

		successbox.hide();

		errorbox.hide();

		

		if($.trim(comment.val()) == '') {

			errorbox.html('Comment is required');

			errorbox.show();

			hideOverlay();

			return false;

		} else if($.trim(post_id.val()) == '') {

			errorbox.html('Refresh the page and try again');

			errorbox.show();

			hideOverlay();

			return false;

		} else {

			$.post(site_path+'/comments', {'_token': token.val(), 'comment' : comment.val(), 'post_id' : post_id.val(), 'reply_to': reply_to.val(), 'thread_id': thread_id.val()}, function(data){

				if(data == 'Success') {

					comment.val('');

					successbox.html('Comment posted successfully!');

					successbox.show();

					$.get(site_path+'/list-comments/'+post_id.val(), function(data){

						if(data == 'Error') {

						} else {

							$('#list_comment_box').html(data);

						}

						hideOverlay();

					});

				} else {

					errorbox.html(data);

					errorbox.show();

					hideOverlay();

					return false;

				}

			});

			

		}

		

	}

	

	function replyComment(reply_to, new_reply_id) {

		var commentForm	= '<div class="row"><div class="col-md-12"><div class="commentform"><div class="col-md-12 col-sm-12"><div class="alert alert-success" role="alert" id="comment_success" style="display:none;"></div><div class="alert alert-danger" role="alert" id="comment_error" style="display:none;"></div></div><div class="col-md-12 col-sm-12"><textarea class="form-control" placeholder="Enter your comments" name="comment" id="comment"></textarea></div><div class="col-md-12 col-sm-12"><input type="hidden" name="reply_to" id="reply_to" value="'+new_reply_id+'"><input type="button" onclick="postComment();" value="Send Comment" class="btn btn-primary" style="position:relative;margin-left:20px;"></div></div></div></div>';

		$('#comment_box').hide();

		$('.comment_reply_class').each(function(){

			$(this).html('');

		});

		$('#comment_reply_'+reply_to).html(commentForm);

	}

	

	function showOverlay() {

		$('.progress-indicator').css('display', 'block');

	}

	function hideOverlay() {

		$('.progress-indicator').css('display', 'none');

	}