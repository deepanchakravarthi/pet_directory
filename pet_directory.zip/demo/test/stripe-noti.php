<?php
	if(mail('deepanchakravarthi.k@gmail.com', 'STRIPE-E', 'Started')) {
		$input = @file_get_contents("php://input");
		
		@mail('deepanchakravarthi.k@gmail.com', 'STRIPE', print_r($input, 1));
		echo 1;
	} else {
		echo 0;
	}
?>