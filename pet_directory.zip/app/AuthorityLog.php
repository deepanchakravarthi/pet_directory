<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AuthorityLog extends Model
{
    protected $table = 'authority_search_log';
}