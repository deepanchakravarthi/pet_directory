<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SendOffer extends Model
{
    protected $table = 'send_offer';
}